document.addEventListener("DOMContentLoaded", () => {
  // Product filter
  initializeProductFilter()

  // Product sort
  initializeProductSort()

  // Product search
  initializeProductSearch()

  // Quick view
  initializeQuickView()

  // Wishlist
  initializeWishlist()
})

// Product filter
function initializeProductFilter() {
  const filterToggles = document.querySelectorAll(".filter-toggle")

  if (filterToggles.length > 0) {
    filterToggles.forEach((toggle) => {
      toggle.addEventListener("click", function () {
        const filterGroup = this.nextElementSibling

        if (filterGroup) {
          filterGroup.classList.toggle("expanded")
          this.classList.toggle("active")
        }
      })
    })
  }

  // Filter checkboxes
  const filterCheckboxes = document.querySelectorAll(".filter-checkbox")
  const productItems = document.querySelectorAll(".product-item")

  if (filterCheckboxes.length > 0 && productItems.length > 0) {
    filterCheckboxes.forEach((checkbox) => {
      checkbox.addEventListener("change", () => {
        applyFilters()
      })
    })

    // Apply all active filters
    function applyFilters() {
      // Get all checked filters
      const checkedFilters = {}

      filterCheckboxes.forEach((checkbox) => {
        if (checkbox.checked) {
          const filterType = checkbox.getAttribute("data-filter-type")
          const filterValue = checkbox.getAttribute("data-filter-value")

          if (!checkedFilters[filterType]) {
            checkedFilters[filterType] = []
          }

          checkedFilters[filterType].push(filterValue)
        }
      })

      // Filter products
      productItems.forEach((item) => {
        let shouldShow = true

        // Check each filter type
        for (const filterType in checkedFilters) {
          const itemValue = item.getAttribute(`data-${filterType}`)

          // If any filter type doesn't match, hide the item
          if (checkedFilters[filterType].length > 0 && !checkedFilters[filterType].includes(itemValue)) {
            shouldShow = false
            break
          }
        }

        // Show or hide item
        if (shouldShow) {
          item.style.display = "block"
          setTimeout(() => {
            item.style.opacity = "1"
            item.style.transform = "translateY(0)"
          }, 10)
        } else {
          item.style.opacity = "0"
          item.style.transform = "translateY(20px)"
          setTimeout(() => {
            item.style.display = "none"
          }, 300)
        }
      })

      // Update filter counts
      updateFilterCounts()
    }

    // Update filter counts
    function updateFilterCounts() {
      const filterCounts = document.querySelectorAll(".filter-count")

      filterCounts.forEach((count) => {
        const filterType = count.getAttribute("data-filter-type")
        const filterValue = count.getAttribute("data-filter-value")
        let matchCount = 0

        // Count visible products that match this filter
        productItems.forEach((item) => {
          if (item.style.display !== "none") {
            const itemValue = item.getAttribute(`data-${filterType}`)

            if (itemValue === filterValue) {
              matchCount++
            }
          }
        })

        count.textContent = `(${matchCount})`
      })
    }

    // Clear filters
    const clearFiltersBtn = document.querySelector(".clear-filters")

    if (clearFiltersBtn) {
      clearFiltersBtn.addEventListener("click", () => {
        filterCheckboxes.forEach((checkbox) => {
          checkbox.checked = false
        })

        // Show all products
        productItems.forEach((item) => {
          item.style.display = "block"
          setTimeout(() => {
            item.style.opacity = "1"
            item.style.transform = "translateY(0)"
          }, 10)
        })

        // Reset filter counts
        updateFilterCounts()
      })
    }
  }
}

// Product sort
function initializeProductSort() {
  const sortSelect = document.querySelector(".sort-select")
  const productGrid = document.querySelector(".product-grid")
  const productItems = document.querySelectorAll(".product-item")

  if (sortSelect && productGrid && productItems.length > 0) {
    sortSelect.addEventListener("change", function () {
      const sortBy = this.value
      const items = Array.from(productItems)

      // Sort items
      items.sort((a, b) => {
        switch (sortBy) {
          case "price-low":
            return Number.parseFloat(a.getAttribute("data-price")) - Number.parseFloat(b.getAttribute("data-price"))
          case "price-high":
            return Number.parseFloat(b.getAttribute("data-price")) - Number.parseFloat(a.getAttribute("data-price"))
          case "name-asc":
            return a.getAttribute("data-name").localeCompare(b.getAttribute("data-name"))
          case "name-desc":
            return b.getAttribute("data-name").localeCompare(a.getAttribute("data-name"))
          case "rating":
            return Number.parseFloat(b.getAttribute("data-rating")) - Number.parseFloat(a.getAttribute("data-rating"))
          case "newest":
            return Number.parseFloat(b.getAttribute("data-date")) - Number.parseFloat(a.getAttribute("data-date"))
          default:
            return 0
        }
      })

      // Reorder items with animation
      items.forEach((item) => {
        item.style.order = items.indexOf(item)
      })

      // Append items to grid
      productGrid.append(...items)
    })
  }
}

function initializeProductSearch() {}

function initializeQuickView() {}

function initializeWishlist() {}
