// About Us Page Interactions
document.addEventListener("DOMContentLoaded", () => {
  initializeCounters()
  initializeTeamCarousel()
  initializePartnerLogos()
  initializeValuesGrid()
})

// Animated Counters
function initializeCounters() {
  const counters = document.querySelectorAll(".stat-counter")

  if (counters.length > 0) {
    const options = {
      threshold: 0.5,
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const counter = entry.target
          const target = Number.parseInt(counter.getAttribute("data-target"))
          const duration = 2000 // 2 seconds
          const step = Math.ceil(target / (duration / 16)) // 60fps

          let current = 0
          const timer = setInterval(() => {
            current += step
            counter.textContent = current

            if (current >= target) {
              counter.textContent = target.toLocaleString()
              clearInterval(timer)
            }
          }, 16)

          observer.unobserve(counter)
        }
      })
    }, options)

    counters.forEach((counter) => {
      observer.observe(counter)
    })
  }
}

// Team Carousel
function initializeTeamCarousel() {
  const teamCarousel = document.querySelector(".team-carousel")
  const teamCards = document.querySelectorAll(".team-card")

  if (teamCarousel && teamCards.length > 0) {
    // Add navigation buttons if not already present
    if (!document.querySelector(".team-carousel-nav")) {
      const navContainer = document.createElement("div")
      navContainer.classList.add("team-carousel-nav")

      const prevBtn = document.createElement("button")
      prevBtn.classList.add("team-prev-btn")
      prevBtn.innerHTML = "&larr;"

      const nextBtn = document.createElement("button")
      nextBtn.classList.add("team-next-btn")
      nextBtn.innerHTML = "&rarr;"

      navContainer.appendChild(prevBtn)
      navContainer.appendChild(nextBtn)

      teamCarousel.appendChild(navContainer)

      // Add event listeners
      let currentPosition = 0
      const cardWidth = teamCards[0].offsetWidth + 20 // Width + margin
      const visibleCards = Math.floor(teamCarousel.offsetWidth / cardWidth)
      const maxPosition = teamCards.length - visibleCards

      prevBtn.addEventListener("click", () => {
        if (currentPosition > 0) {
          currentPosition--
          updatePosition()
        }
      })

      nextBtn.addEventListener("click", () => {
        if (currentPosition < maxPosition) {
          currentPosition++
          updatePosition()
        }
      })

      function updatePosition() {
        const translateX = -currentPosition * cardWidth
        document.querySelector(".team-grid").style.transform = `translateX(${translateX}px)`
      }
    }

    // Add social media hover effects
    const socialLinks = document.querySelectorAll(".team-social a")

    socialLinks.forEach((link) => {
      link.addEventListener("mouseenter", function () {
        this.classList.add("pulse")
      })

      link.addEventListener("mouseleave", function () {
        this.classList.remove("pulse")
      })
    })
  }
}

// Partner Logos Animation
function initializePartnerLogos() {
  const partnerLogos = document.querySelectorAll(".partner-logo")

  if (partnerLogos.length > 0) {
    partnerLogos.forEach((logo) => {
      logo.addEventListener("mouseenter", function () {
        this.classList.add("scale-up")
      })

      logo.addEventListener("mouseleave", function () {
        this.classList.remove("scale-up")
      })
    })
  }
}

// Values Grid Interactions
function initializeValuesGrid() {
  const valueCards = document.querySelectorAll(".value-card")

  if (valueCards.length > 0) {
    valueCards.forEach((card) => {
      card.addEventListener("mouseenter", function () {
        this.classList.add("active")
      })

      card.addEventListener("mouseleave", function () {
        this.classList.remove("active")
      })
    })
  }
}

// Timeline animation
function initializeTimeline() {
  const timelineItems = document.querySelectorAll(".timeline-item")

  if (timelineItems.length > 0) {
    const options = {
      threshold: 0.2,
      rootMargin: "0px 0px -100px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible")
          observer.unobserve(entry.target)
        }
      })
    }, options)

    timelineItems.forEach((item) => {
      observer.observe(item)
    })
  }
}

// Testimonial slider
function initializeTestimonialSlider() {
  const testimonialSlider = document.querySelector(".testimonial-slider")
  const testimonials = document.querySelectorAll(".testimonial")

  if (testimonialSlider && testimonials.length > 0) {
    let currentIndex = 0

    // Create navigation dots if they don't exist
    if (!document.querySelector(".testimonial-dots")) {
      const dotsContainer = document.createElement("div")
      dotsContainer.className = "testimonial-dots"

      testimonials.forEach((_, index) => {
        const dot = document.createElement("span")
        dot.className = "testimonial-dot"
        if (index === 0) dot.classList.add("active")

        dot.addEventListener("click", () => {
          currentIndex = index
          updateSlider()
        })

        dotsContainer.appendChild(dot)
      })

      testimonialSlider.parentNode.appendChild(dotsContainer)
    }

    // Auto-advance slider
    let sliderInterval = setInterval(nextSlide, 5000)

    function nextSlide() {
      currentIndex = (currentIndex + 1) % testimonials.length
      updateSlider()
    }

    // Update slider position and active dot
    function updateSlider() {
      testimonialSlider.style.transform = `translateX(-${currentIndex * 100}%)`

      const dots = document.querySelectorAll(".testimonial-dot")
      dots.forEach((dot, index) => {
        dot.classList.toggle("active", index === currentIndex)
      })

      // Reset interval
      clearInterval(sliderInterval)
      sliderInterval = setInterval(nextSlide, 5000)
    }

    // Pause auto-advance on hover
    testimonialSlider.addEventListener("mouseenter", () => {
      clearInterval(sliderInterval)
    })

    testimonialSlider.addEventListener("mouseleave", () => {
      sliderInterval = setInterval(nextSlide, 5000)
    })
  }
}

// Newsletter form functionality
function initializeNewsletterForm() {
  const newsletterForm = document.querySelector(".subscribe-form")

  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault()

      const emailInput = this.querySelector('input[type="email"]')
      const email = emailInput.value.trim()

      if (email === "") {
        // Show error
        emailInput.style.borderColor = "#f44336"

        // Reset after 2 seconds
        setTimeout(() => {
          emailInput.style.borderColor = ""
        }, 2000)

        return
      }

      // Show success message
      const button = this.querySelector("button")
      const originalText = button.textContent

      button.innerHTML = '<i class="fas fa-check"></i> Subscribed!'
      button.style.backgroundColor = "#4caf50"

      // Reset form after 2 seconds
      setTimeout(() => {
        emailInput.value = ""
        button.textContent = originalText
        button.style.backgroundColor = ""
      }, 2000)
    })
  }
}

// Add animation classes
function addAnimationClasses() {
  // Add animate-on-scroll class to elements
  const elementsToAnimate = [
    ".hero-content",
    ".hero-image",
    ".mission-content",
    ".mission-image",
    ".mission-point",
    ".team-card",
    ".value-card",
    ".partner-logos",
    ".central-logo",
    ".newsletter-content",
    ".newsletter-image",
  ]

  elementsToAnimate.forEach((selector) => {
    document.querySelectorAll(selector).forEach((element) => {
      if (!element.classList.contains("animate-on-scroll")) {
        element.classList.add("animate-on-scroll")
      }
    })
  })

  // Add pulse animation to stat items
  document.querySelectorAll(".stat-item").forEach((item) => {
    item.addEventListener("mouseenter", function () {
      this.classList.add("pulse")
    })

    item.addEventListener("mouseleave", function () {
      this.classList.remove("pulse")
    })
  })

  // Add pulse animation style
  const style = document.createElement("style")
  style.textContent = `
    @keyframes pulse {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.05);
      }
      100% {
        transform: scale(1);
      }
    }
    
    .pulse {
      animation: pulse 0.5s;
    }
  `
  document.head.appendChild(style)
}
