// 404 Page Interactions
document.addEventListener("DOMContentLoaded", () => {
  initializeParticles()
  initializeSearchBox()
  initializeSuggestedLinks()
})

// Animated Particles
function initializeParticles() {
  const particlesContainer = document.querySelector(".particles-container")

  if (particlesContainer) {
    // Create canvas
    const canvas = document.createElement("canvas")
    canvas.classList.add("particles-canvas")
    particlesContainer.appendChild(canvas)

    const ctx = canvas.getContext("2d")

    // Set canvas size
    function resizeCanvas() {
      canvas.width = particlesContainer.offsetWidth
      canvas.height = particlesContainer.offsetHeight
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Particle class
    class Particle {
      constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height
        this.size = Math.random() * 5 + 1
        this.speedX = Math.random() * 3 - 1.5
        this.speedY = Math.random() * 3 - 1.5
        this.color = `rgba(${Math.floor(Math.random() * 100) + 155}, ${Math.floor(Math.random() * 100) + 155}, ${Math.floor(Math.random() * 100) + 155}, ${Math.random() * 0.5 + 0.5})`
      }

      update() {
        this.x += this.speedX
        this.y += this.speedY

        // Bounce off edges
        if (this.x < 0 || this.x > canvas.width) {
          this.speedX = -this.speedX
        }

        if (this.y < 0 || this.y > canvas.height) {
          this.speedY = -this.speedY
        }
      }

      draw() {
        ctx.fillStyle = this.color
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    // Create particles
    const particles = []
    const particleCount = 50

    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle())
    }

    // Animation loop
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((particle) => {
        particle.update()
        particle.draw()
      })

      requestAnimationFrame(animate)
    }

    animate()

    // Mouse interaction
    let mouseX = 0
    let mouseY = 0

    particlesContainer.addEventListener("mousemove", (e) => {
      const rect = canvas.getBoundingClientRect()
      mouseX = e.clientX - rect.left
      mouseY = e.clientY - rect.top

      // Attract particles to mouse
      particles.forEach((particle) => {
        const dx = mouseX - particle.x
        const dy = mouseY - particle.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < 100) {
          const angle = Math.atan2(dy, dx)
          particle.speedX += Math.cos(angle) * 0.2
          particle.speedY += Math.sin(angle) * 0.2
        }
      })
    })
  }
}

// Search Box Functionality
function initializeSearchBox() {
  const searchForm = document.querySelector(".error-search-form")
  const searchInput = document.querySelector(".error-search-input")

  if (searchForm && searchInput) {
    searchForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const searchTerm = searchInput.value.trim()

      if (searchTerm) {
        // Simulate search
        const searchResultsContainer = document.querySelector(".search-results")

        if (!searchResultsContainer) {
          const resultsContainer = document.createElement("div")
          resultsContainer.classList.add("search-results")

          resultsContainer.innerHTML = `
                        <h3>Search Results for "${searchTerm}"</h3>
                        <p>Searching...</p>
                    `

          searchForm.parentNode.insertBefore(resultsContainer, searchForm.nextSibling)

          // Simulate loading
          setTimeout(() => {
            resultsContainer.innerHTML = `
                            <h3>Search Results for "${searchTerm}"</h3>
                            <p>No exact matches found. Try one of our suggested links below.</p>
                        `
          }, 1500)
        } else {
          searchResultsContainer.innerHTML = `
                        <h3>Search Results for "${searchTerm}"</h3>
                        <p>Searching...</p>
                    `

          // Simulate loading
          setTimeout(() => {
            searchResultsContainer.innerHTML = `
                            <h3>Search Results for "${searchTerm}"</h3>
                            <p>No exact matches found. Try one of our suggested links below.</p>
                        `
          }, 1500)
        }
      }
    })

    // Add focus effects
    searchInput.addEventListener("focus", function () {
      this.parentNode.classList.add("focused")
    })

    searchInput.addEventListener("blur", function () {
      this.parentNode.classList.remove("focused")
    })
  }
}

// Suggested Links Animation
function initializeSuggestedLinks() {
  const suggestedLinks = document.querySelectorAll(".suggested-link")

  if (suggestedLinks.length > 0) {
    suggestedLinks.forEach((link) => {
      link.addEventListener("mouseenter", function () {
        this.classList.add("pulse")
      })

      link.addEventListener("mouseleave", function () {
        this.classList.remove("pulse")
      })
    })
  }
}

// Add animation classes
function addAnimationClasses() {
  // Add animate-on-scroll class to elements
  const elementsToAnimate = [
    ".error-code",
    ".error-title",
    ".error-message",
    ".error-actions",
    ".search-container",
    ".error-image",
    ".suggested-section",
  ]

  elementsToAnimate.forEach((selector) => {
    document.querySelectorAll(selector).forEach((element) => {
      if (!element.classList.contains("animate-on-scroll")) {
        element.classList.add("animate-on-scroll")
      }
    })
  })

  // Add typing animation to error title
  const errorTitle = document.querySelector(".error-title")

  if (errorTitle) {
    const text = errorTitle.textContent
    errorTitle.textContent = ""

    // Create typing animation
    let i = 0
    const typing = setInterval(() => {
      if (i < text.length) {
        errorTitle.textContent += text.charAt(i)
        i++
      } else {
        clearInterval(typing)
      }
    }, 50)
  }
}

// Robot animation
function initializeRobot() {
  const robot = document.querySelector(".error-robot")

  if (robot) {
    // Add hover animation
    robot.addEventListener("mouseenter", function () {
      this.classList.add("animated")
    })

    // Random movements
    setInterval(() => {
      const randomMove = Math.floor(Math.random() * 3)

      robot.classList.remove("move-left", "move-right", "move-up")

      switch (randomMove) {
        case 0:
          robot.classList.add("move-left")
          break
        case 1:
          robot.classList.add("move-right")
          break
        case 2:
          robot.classList.add("move-up")
          break
      }

      setTimeout(() => {
        robot.classList.remove("move-left", "move-right", "move-up")
      }, 1000)
    }, 3000)

    // Add speech bubble on click
    robot.addEventListener("click", () => {
      // Remove existing speech bubble
      const existingBubble = document.querySelector(".robot-speech")
      if (existingBubble) {
        document.body.removeChild(existingBubble)
        return
      }

      // Create speech bubble
      const speechBubble = document.createElement("div")
      speechBubble.className = "robot-speech"

      // Random messages
      const messages = [
        "Oops! Looks like you're lost in cyberspace!",
        "404: Page not found. But I found you!",
        "This page has gone on vacation. Try another one!",
        "Houston, we have a problem. This page doesn't exist.",
        "Even robots make mistakes sometimes!",
      ]

      const randomMessage = messages[Math.floor(Math.random() * messages.length)]
      speechBubble.textContent = randomMessage

      // Position speech bubble
      const robotRect = robot.getBoundingClientRect()
      speechBubble.style.position = "absolute"
      speechBubble.style.top = robotRect.top - 80 + "px"
      speechBubble.style.left = robotRect.left + robotRect.width / 2 - 100 + "px"

      document.body.appendChild(speechBubble)

      // Remove speech bubble after a few seconds
      setTimeout(() => {
        if (document.body.contains(speechBubble)) {
          speechBubble.style.opacity = "0"
          setTimeout(() => {
            if (document.body.contains(speechBubble)) {
              document.body.removeChild(speechBubble)
            }
          }, 300)
        }
      }, 3000)
    })
  }
}
