// Services Page Interactions
document.addEventListener("DOMContentLoaded", () => {
  initializeServiceCards()
  initializeFloatingElements()
  initializeTestimonials()
  initializeFAQAccordion()
})

// Service Cards Interactions
function initializeServiceCards() {
  const serviceCards = document.querySelectorAll(".service-card")

  if (serviceCards.length > 0) {
    serviceCards.forEach((card) => {
      card.addEventListener("mouseenter", function () {
        this.classList.add("active")

        // Animate icon
        const icon = this.querySelector(".service-icon")
        if (icon) {
          icon.classList.add("bounce")
          setTimeout(() => {
            icon.classList.remove("bounce")
          }, 1000)
        }
      })

      card.addEventListener("mouseleave", function () {
        this.classList.remove("active")
      })

      // Add click functionality
      card.addEventListener("click", function () {
        const serviceId = this.getAttribute("data-service-id")
        const serviceDetails = document.querySelector(`.service-details[data-service-id="${serviceId}"]`)

        if (serviceDetails) {
          // Scroll to details
          serviceDetails.scrollIntoView({
            behavior: "smooth",
            block: "start",
          })

          // Highlight details
          serviceDetails.classList.add("highlight")
          setTimeout(() => {
            serviceDetails.classList.remove("highlight")
          }, 1500)
        }
      })
    })
  }
}

// Floating Elements Animation
function initializeFloatingElements() {
  const floatingElements = document.querySelectorAll(".floating-element")

  if (floatingElements.length > 0) {
    floatingElements.forEach((element, index) => {
      // Set random animation duration and delay
      const duration = 3 + Math.random() * 2 // 3-5 seconds
      const delay = Math.random() * 2 // 0-2 seconds

      element.style.animationDuration = `${duration}s`
      element.style.animationDelay = `${delay}s`

      // Add mouse parallax effect
      document.addEventListener("mousemove", (e) => {
        const moveX = (e.clientX - window.innerWidth / 2) * 0.01
        const moveY = (e.clientY - window.innerHeight / 2) * 0.01

        // Different movement for each element
        const factor = (index % 3) + 1
        element.style.transform = `translate(${moveX * factor}px, ${moveY * factor}px)`
      })
    })
  }
}

// Testimonials Slider
function initializeTestimonials() {
  const testimonialContainer = document.querySelector(".testimonials-container")
  const testimonials = document.querySelectorAll(".testimonial")

  if (testimonialContainer && testimonials.length > 0) {
    // Add navigation dots if not already present
    if (!document.querySelector(".testimonial-dots")) {
      const dotsContainer = document.createElement("div")
      dotsContainer.classList.add("testimonial-dots")

      testimonials.forEach((_, index) => {
        const dot = document.createElement("span")
        dot.classList.add("testimonial-dot")
        if (index === 0) {
          dot.classList.add("active")
        }

        dot.addEventListener("click", () => {
          showTestimonial(index)
        })

        dotsContainer.appendChild(dot)
      })

      testimonialContainer.appendChild(dotsContainer)
    }

    // Add auto-rotation
    let currentIndex = 0
    const interval = 5000 // 5 seconds

    const autoRotate = setInterval(() => {
      currentIndex = (currentIndex + 1) % testimonials.length
      showTestimonial(currentIndex)
    }, interval)

    // Pause rotation on hover
    testimonialContainer.addEventListener("mouseenter", () => {
      clearInterval(autoRotate)
    })

    testimonialContainer.addEventListener("mouseleave", () => {
      clearInterval(autoRotate)
      autoRotate = setInterval(() => {
        currentIndex = (currentIndex + 1) % testimonials.length
        showTestimonial(currentIndex)
      }, interval)
    })

    function showTestimonial(index) {
      // Update testimonials
      testimonials.forEach((testimonial, i) => {
        testimonial.classList.remove("active")
        if (i === index) {
          testimonial.classList.add("active")
        }
      })

      // Update dots
      const dots = document.querySelectorAll(".testimonial-dot")
      dots.forEach((dot, i) => {
        dot.classList.remove("active")
        if (i === index) {
          dot.classList.add("active")
        }
      })

      currentIndex = index
    }
  }
}

// FAQ Accordion
function initializeFAQAccordion() {
  const faqItems = document.querySelectorAll(".faq-item")

  if (faqItems.length > 0) {
    faqItems.forEach((item) => {
      const question = item.querySelector(".faq-question")
      const answer = item.querySelector(".faq-answer")

      if (question && answer) {
        question.addEventListener("click", () => {
          // Close other items
          faqItems.forEach((otherItem) => {
            if (otherItem !== item) {
              otherItem.classList.remove("active")
              otherItem.querySelector(".faq-answer").style.maxHeight = null
            }
          })

          // Toggle current item
          item.classList.toggle("active")

          if (item.classList.contains("active")) {
            answer.style.maxHeight = answer.scrollHeight + "px"
          } else {
            answer.style.maxHeight = null
          }
        })
      }
    })
  }
}
