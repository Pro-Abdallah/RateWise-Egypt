document.addEventListener("DOMContentLoaded", () => {
  // News filter
  initializeNewsFilter()

  // News search
  initializeNewsSearch()

  // Share functionality
  initializeShareButtons()

  // Read more functionality
  initializeReadMore()
})

// News filter
function initializeNewsFilter() {
  const filterButtons = document.querySelectorAll(".news-filter-btn")
  const newsItems = document.querySelectorAll(".news-item")

  if (filterButtons.length > 0 && newsItems.length > 0) {
    filterButtons.forEach((button) => {
      button.addEventListener("click", function () {
        // Update active button
        filterButtons.forEach((btn) => btn.classList.remove("active"))
        this.classList.add("active")

        // Filter news
        const category = this.getAttribute("data-category")

        newsItems.forEach((item) => {
          if (category === "all") {
            item.style.display = "block"
            setTimeout(() => {
              item.style.opacity = "1"
              item.style.transform = "translateY(0)"
            }, 10)
          } else {
            const itemCategory = item.getAttribute("data-category")

            if (itemCategory === category) {
              item.style.display = "block"
              setTimeout(() => {
                item.style.opacity = "1"
                item.style.transform = "translateY(0)"
              }, 10)
            } else {
              item.style.opacity = "0"
              item.style.transform = "translateY(20px)"
              setTimeout(() => {
                item.style.display = "none"
              }, 300)
            }
          }
        })
      })
    })
  }
}

// News search
function initializeNewsSearch() {
  const searchForm = document.querySelector(".news-search-form")
  const searchInput = document.querySelector(".news-search-input")
  const newsItems = document.querySelectorAll(".news-item")

  if (searchForm && searchInput && newsItems.length > 0) {
    searchForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const searchTerm = searchInput.value.trim().toLowerCase()

      if (searchTerm) {
        // Filter news items
        let matchFound = false

        newsItems.forEach((item) => {
          const title = item.querySelector(".news-title").textContent.toLowerCase()
          const content = item.querySelector(".news-content").textContent.toLowerCase()

          if (title.includes(searchTerm) || content.includes(searchTerm)) {
            item.style.display = "block"
            setTimeout(() => {
              item.style.opacity = "1"
              item.style.transform = "translateY(0)"
            }, 10)

            // Highlight matching text
            highlightText(item, searchTerm)

            matchFound = true
          } else {
            item.style.opacity = "0"
            item.style.transform = "translateY(20px)"
            setTimeout(() => {
              item.style.display = "none"
            }, 300)
          }
        })

        // Show no results message
        const noResultsMessage = document.querySelector(".no-results-message")
        if (noResultsMessage) {
          if (!matchFound) {
            noResultsMessage.style.display = "block"
          } else {
            noResultsMessage.style.display = "none"
          }
        }

        // Reset filter buttons
        const filterButtons = document.querySelectorAll(".news-filter-btn")
        filterButtons.forEach((btn) => btn.classList.remove("active"))
        filterButtons[0].classList.add("active") // Select "All" button
      } else {
        // Show all items if search is empty
        newsItems.forEach((item) => {
          item.style.display = "block"
          setTimeout(() => {
            item.style.opacity = "1"
            item.style.transform = "translateY(0)"
          }, 10)

          // Remove highlights
          removeHighlights(item)
        })

        // Hide no results message
        const noResultsMessage = document.querySelector(".no-results-message")
        if (noResultsMessage) {
          noResultsMessage.style.display = "none"
        }
      }
    })

    // Clear search
    const clearButton = searchForm.querySelector(".clear-search")
    if (clearButton) {
      clearButton.addEventListener("click", () => {
        searchInput.value = ""

        // Show all items
        newsItems.forEach((item) => {
          item.style.display = "block"
          setTimeout(() => {
            item.style.opacity = "1"
            item.style.transform = "translateY(0)"
          }, 10)

          // Remove highlights
          removeHighlights(item)
        })

        // Hide no results message
        const noResultsMessage = document.querySelector(".no-results-message")
        if (noResultsMessage) {
          noResultsMessage.style.display = "none"
        }

        // Reset filter buttons
        const filterButtons = document.querySelectorAll(".news-filter-btn")
        filterButtons.forEach((btn) => btn.classList.remove("active"))
        filterButtons[0].classList.add("active") // Select "All" button
      })
    }
  }
}

// Helper function to highlight text
function highlightText(container, term) {
  // Remove existing highlights
  removeHighlights(container)

  const textNodes = getTextNodes(container)

  textNodes.forEach((node) => {
    const text = node.textContent
    const lowerText = text.toLowerCase()
    const position = lowerText.indexOf(term.toLowerCase())

    if (position !== -1) {
      const spanNode = document.createElement("span")
      spanNode.className = "highlight"

      const before = document.createTextNode(text.substring(0, position))
      const highlight = document.createTextNode(text.substring(position, position + term.length))
      const after = document.createTextNode(text.substring(position + term.length))

      spanNode.appendChild(highlight)

      const parentNode = node.parentNode
      parentNode.replaceChild(after, node)
      parentNode.insertBefore(spanNode, after)
      parentNode.insertBefore(before, spanNode)
    }
  })
}

// Helper function to remove highlights
function removeHighlights(container) {
  const highlights = container.querySelectorAll(".highlight")

  highlights.forEach((highlight) => {
    const parent = highlight.parentNode
    const textNode = document.createTextNode(highlight.textContent)
    parent.replaceChild(textNode, highlight)
    parent.normalize()
  })
}

// Helper function to get text nodes
function getTextNodes(node) {
  const textNodes = []

  function getNodes(node) {
    if (node.nodeType === 3) {
      textNodes.push(node)
    } else {
      const children = node.childNodes
      for (let i = 0; i < children.length; i++) {
        getNodes(children[i])
      }
    }
  }

  getNodes(node)
  return textNodes
}

// Share functionality
function initializeShareButtons() {
  const shareButtons = document.querySelectorAll(".share-button")

  if (shareButtons.length > 0) {
    shareButtons.forEach((button) => {
      button.addEventListener("click", function (e) {
        e.preventDefault()

        const platform = this.getAttribute("data-platform")
        const newsItem = this.closest(".news-item")

        if (newsItem) {
          const title = newsItem.querySelector(".news-title").textContent
          const url = window.location.href

          let shareUrl

          switch (platform) {
            case "facebook":
              shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&t=${encodeURIComponent(title)}`
              break
            case "twitter":
              shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`
              break
            case "linkedin":
              shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`
              break
            case "email":
              shareUrl = `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(url)}`
              break
          }

          if (shareUrl) {
            window.open(shareUrl, "_blank", "width=600,height=400")
          }
        }
      })
    })
  }
}

// Read more functionality
function initializeReadMore() {
  const readMoreButtons = document.querySelectorAll(".read-more")

  if (readMoreButtons.length > 0) {
    readMoreButtons.forEach((button) => {
      button.addEventListener("click", function (e) {
        e.preventDefault()

        const newsItem = this.closest(".news-item")

        if (newsItem) {
          const content = newsItem.querySelector(".news-content")

          if (content) {
            if (content.classList.contains("expanded")) {
              // Collapse
              content.classList.remove("expanded")
              this.textContent = "Read More"

              // Scroll back to top of news item
              newsItem.scrollIntoView({ behavior: "smooth" })
            } else {
              // Expand
              content.classList.add("expanded")
              this.textContent = "Read Less"
            }
          }
        }
      })
    })
  }
}
