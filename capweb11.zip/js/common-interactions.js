// Common interactions for all pages
document.addEventListener("DOMContentLoaded", () => {
  // Initialize all interactive elements
  initializeNavbar()
  initializeButtons()
  initializeHoverEffects()
  initializeScrollAnimations()
  initializeTooltips()
  initializeDropdowns()
  initializeModals()
  initializeFooter()
  initializeAccordions()
  initializeTabSwitching()
  initializeQuantitySelectors()
  initializeColorSelectors()
  initializeHeartToggle()
  initializeCarousels()
  initializeAnimations()
  initializeSearchFunctionality()
})

// Navbar functionality
function initializeNavbar() {
  // Mobile menu toggle
  const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
  const navMenu = document.querySelector(".nav-menu")

  if (mobileMenuToggle && navMenu) {
    mobileMenuToggle.addEventListener("click", function () {
      navMenu.classList.toggle("active")
      this.classList.toggle("active")
    })
  }

  // Dropdown menus in navbar
  const dropdownToggles = document.querySelectorAll(".dropdown-toggle")

  dropdownToggles.forEach((toggle) => {
    toggle.addEventListener("click", function (e) {
      e.preventDefault()
      const dropdown = this.nextElementSibling

      // Close all other dropdowns
      dropdownToggles.forEach((otherToggle) => {
        if (otherToggle !== toggle) {
          otherToggle.nextElementSibling.classList.remove("show")
        }
      })

      dropdown.classList.toggle("show")
    })
  })

  // Close dropdowns when clicking outside
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".dropdown")) {
      document.querySelectorAll(".dropdown-menu").forEach((menu) => {
        menu.classList.remove("show")
      })
    }
  })

  // Highlight active page in navigation
  const currentPage = window.location.pathname.split("/").pop()
  const navLinks = document.querySelectorAll(".nav-link")

  navLinks.forEach((link) => {
    const href = link.getAttribute("href")
    if (href === currentPage) {
      link.classList.add("active")
    }
  })

  // Sticky header on scroll
  const header = document.querySelector("header")
  let lastScrollTop = 0

  if (header) {
    window.addEventListener("scroll", () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop

      if (scrollTop > 100) {
        header.classList.add("sticky")

        if (scrollTop > lastScrollTop) {
          // Scrolling down
          header.classList.add("hide")
        } else {
          // Scrolling up
          header.classList.remove("hide")
        }
      } else {
        header.classList.remove("sticky")
      }

      lastScrollTop = scrollTop
    })
  }
}

// Button interactions
function initializeButtons() {
  const buttons = document.querySelectorAll("button, .btn, .button")

  buttons.forEach((button) => {
    // Add ripple effect
    button.addEventListener("click", function (e) {
      const rect = this.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      const ripple = document.createElement("span")
      ripple.classList.add("ripple")
      ripple.style.left = x + "px"
      ripple.style.top = y + "px"

      this.appendChild(ripple)

      setTimeout(() => {
        ripple.remove()
      }, 600)
    })
  })
}

// Hover effects
function initializeHoverEffects() {
  // Card hover effects
  const cards = document.querySelectorAll(".card, .product-card, .team-card, .service-card")

  cards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.classList.add("hover")
    })

    card.addEventListener("mouseleave", function () {
      this.classList.remove("hover")
    })
  })

  // Button hover effects
  const buttons = document.querySelectorAll("button, .btn, .button")

  buttons.forEach((button) => {
    button.addEventListener("mouseenter", function () {
      this.classList.add("hover")
    })

    button.addEventListener("mouseleave", function () {
      this.classList.remove("hover")
    })
  })
}

// Scroll animations
function initializeScrollAnimations() {
  const animatedElements = document.querySelectorAll(".animate-on-scroll")

  const checkIfInView = () => {
    const windowHeight = window.innerHeight
    const windowTopPosition = window.scrollY
    const windowBottomPosition = windowTopPosition + windowHeight

    animatedElements.forEach((element) => {
      const elementHeight = element.offsetHeight
      const elementTopPosition = element.offsetTop
      const elementBottomPosition = elementTopPosition + elementHeight

      // Check if element is in viewport
      if (elementBottomPosition >= windowTopPosition && elementTopPosition <= windowBottomPosition) {
        element.classList.add("animated")
      }
    })
  }

  window.addEventListener("scroll", checkIfInView)
  window.addEventListener("resize", checkIfInView)

  // Trigger on initial load
  checkIfInView()
}

// Tooltips
function initializeTooltips() {
  const tooltipTriggers = document.querySelectorAll("[data-tooltip]")

  tooltipTriggers.forEach((trigger) => {
    const tooltipText = trigger.getAttribute("data-tooltip")
    const tooltip = document.createElement("div")
    tooltip.classList.add("tooltip")
    tooltip.textContent = tooltipText

    trigger.appendChild(tooltip)

    trigger.addEventListener("mouseenter", () => {
      tooltip.classList.add("show")
    })

    trigger.addEventListener("mouseleave", () => {
      tooltip.classList.remove("show")
    })
  })
}

// Dropdown functionality
function initializeDropdowns() {
  const dropdowns = document.querySelectorAll(".dropdown")

  dropdowns.forEach((dropdown) => {
    const trigger = dropdown.querySelector(".dropdown-trigger")
    const content = dropdown.querySelector(".dropdown-content")

    if (trigger && content) {
      trigger.addEventListener("click", (e) => {
        e.preventDefault()
        content.classList.toggle("show")
      })

      // Close when clicking outside
      document.addEventListener("click", (e) => {
        if (!dropdown.contains(e.target)) {
          content.classList.remove("show")
        }
      })
    }
  })
}

// Modal functionality
function initializeModals() {
  const modalTriggers = document.querySelectorAll("[data-modal]")

  modalTriggers.forEach((trigger) => {
    const modalId = trigger.getAttribute("data-modal")
    const modal = document.getElementById(modalId)

    if (modal) {
      const closeBtn = modal.querySelector(".modal-close")

      trigger.addEventListener("click", (e) => {
        e.preventDefault()
        modal.classList.add("show")
        document.body.classList.add("modal-open")
      })

      if (closeBtn) {
        closeBtn.addEventListener("click", () => {
          modal.classList.remove("show")
          document.body.classList.remove("modal-open")
        })
      }

      // Close when clicking outside the modal content
      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          modal.classList.remove("show")
          document.body.classList.remove("modal-open")
        }
      })

      // Close with Escape key
      document.addEventListener("keydown", (e) => {
        if (e.key === "Escape" && modal.classList.contains("show")) {
          modal.classList.remove("show")
          document.body.classList.remove("modal-open")
        }
      })
    }
  })
}

// Footer interactions
function initializeFooter() {
  // Footer accordion for mobile
  const footerHeadings = document.querySelectorAll(".footer-heading")

  footerHeadings.forEach((heading) => {
    heading.addEventListener("click", function () {
      // Only apply on mobile
      if (window.innerWidth < 768) {
        this.classList.toggle("active")
        const content = this.nextElementSibling

        if (content) {
          if (content.style.maxHeight) {
            content.style.maxHeight = null
          } else {
            content.style.maxHeight = content.scrollHeight + "px"
          }
        }
      }
    })
  })

  // Back to top button
  const backToTopBtn = document.querySelector(".back-to-top")

  if (backToTopBtn) {
    window.addEventListener("scroll", () => {
      if (window.pageYOffset > 300) {
        backToTopBtn.classList.add("show")
      } else {
        backToTopBtn.classList.remove("show")
      }
    })

    backToTopBtn.addEventListener("click", (e) => {
      e.preventDefault()
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      })
    })
  }
}

// Accordion functionality
function initializeAccordions() {
  const accordionHeaders = document.querySelectorAll(".accordion-header")

  accordionHeaders.forEach((header) => {
    header.addEventListener("click", function () {
      const accordionItem = this.parentElement
      const accordionContent = this.nextElementSibling
      const isActive = accordionItem.classList.contains("active")

      // If it's not a multi-accordion, close all other items
      if (!accordionItem.closest(".accordion").classList.contains("multi")) {
        const siblings = accordionItem.parentElement.querySelectorAll(".accordion-item")
        siblings.forEach((sibling) => {
          if (sibling !== accordionItem) {
            sibling.classList.remove("active")
            sibling.querySelector(".accordion-content").style.maxHeight = "0"
          }
        })
      }

      // Toggle current item
      accordionItem.classList.toggle("active", !isActive)

      if (!isActive) {
        accordionContent.style.maxHeight = accordionContent.scrollHeight + "px"
      } else {
        accordionContent.style.maxHeight = "0"
      }
    })
  })
}

// Tab switching functionality
function initializeTabSwitching() {
  const tabButtons = document.querySelectorAll(".tab-btn")

  tabButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const tabId = this.getAttribute("data-tab")
      const tabContainer = this.closest(".tabs-container") || document.body

      // Remove active class from all buttons and contents
      tabContainer.querySelectorAll(".tab-btn").forEach((btn) => {
        btn.classList.remove("active")
      })

      tabContainer.querySelectorAll(".tab-content").forEach((content) => {
        content.classList.remove("active")
      })

      // Add active class to clicked button and corresponding content
      this.classList.add("active")
      const tabContent = tabContainer.querySelector(`#${tabId}`) || document.getElementById(tabId)
      if (tabContent) {
        tabContent.classList.add("active")
      }
    })
  })
}

// Quantity selector functionality
function initializeQuantitySelectors() {
  const quantitySelectors = document.querySelectorAll(".quantity-selector")

  quantitySelectors.forEach((selector) => {
    const minusBtn = selector.querySelector(".minus")
    const plusBtn = selector.querySelector(".plus")
    const input = selector.querySelector("input")

    if (minusBtn && plusBtn && input) {
      minusBtn.addEventListener("click", () => {
        const value = Number.parseInt(input.value)
        if (value > Number.parseInt(input.getAttribute("min") || 1)) {
          input.value = value - 1
          // Trigger change event
          const event = new Event("change")
          input.dispatchEvent(event)
        }
      })

      plusBtn.addEventListener("click", () => {
        const value = Number.parseInt(input.value)
        const max = Number.parseInt(input.getAttribute("max") || 999)
        if (value < max) {
          input.value = value + 1
          // Trigger change event
          const event = new Event("change")
          input.dispatchEvent(event)
        }
      })

      // Validate input on change
      input.addEventListener("change", function () {
        const value = Number.parseInt(this.value)
        const min = Number.parseInt(this.getAttribute("min") || 1)
        const max = Number.parseInt(this.getAttribute("max") || 999)

        if (isNaN(value) || value < min) {
          this.value = min
        } else if (value > max) {
          this.value = max
        }
      })
    }
  })
}

// Color selector functionality
function initializeColorSelectors() {
  const colorOptions = document.querySelectorAll(".color-option")

  colorOptions.forEach((option) => {
    option.addEventListener("click", function () {
      const colorContainer = this.closest(".color-options")

      // Remove active class from all options
      colorContainer.querySelectorAll(".color-option").forEach((opt) => {
        opt.classList.remove("active")
      })

      // Add active class to clicked option
      this.classList.add("active")
    })
  })
}

// Heart toggle functionality
function initializeHeartToggle() {
  const heartButtons = document.querySelectorAll(".wishlist-btn, .action-icon:has(.fa-heart)")

  heartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const heartIcon = this.querySelector("i.fa-heart")

      if (heartIcon) {
        if (heartIcon.classList.contains("far")) {
          heartIcon.classList.remove("far")
          heartIcon.classList.add("fas")
          heartIcon.classList.add("heart-active")
        } else {
          heartIcon.classList.remove("fas")
          heartIcon.classList.remove("heart-active")
          heartIcon.classList.add("far")
        }
      }
    })
  })
}

// Carousel functionality
function initializeCarousels() {
  const carousels = document.querySelectorAll(".team-carousel, .testimonials-slider")

  carousels.forEach((carousel) => {
    const prevBtn = carousel.querySelector(".prev")
    const nextBtn = carousel.querySelector(".next")
    const slidesContainer = carousel.querySelector(".team-cards, .testimonials-slider")

    if (prevBtn && nextBtn && slidesContainer) {
      // Next button click
      nextBtn.addEventListener("click", () => {
        slidesContainer.scrollBy({
          left: 300,
          behavior: "smooth",
        })
      })

      // Previous button click
      prevBtn.addEventListener("click", () => {
        slidesContainer.scrollBy({
          left: -300,
          behavior: "smooth",
        })
      })
    }
  })
}

// Animation functionality
function initializeAnimations() {
  // Animate elements when they come into view
  const animatedElements = document.querySelectorAll(".animate-on-scroll")

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animated")
          observer.unobserve(entry.target)
        }
      })
    },
    { threshold: 0.1 },
  )

  animatedElements.forEach((element) => {
    observer.observe(element)
  })

  // Add animate-on-scroll class to elements that should animate
  document
    .querySelectorAll(".feature-card, .value-card, .service-card, .team-card, .product-card")
    .forEach((element) => {
      if (!element.classList.contains("animate-on-scroll")) {
        element.classList.add("animate-on-scroll")
      }
    })
}

// Form validation
function validateForm(event) {
  const form = event.target
  const inputs = form.querySelectorAll("input, textarea, select")
  let isValid = true

  inputs.forEach((input) => {
    if (input.hasAttribute("required") && !input.value.trim()) {
      isValid = false
      showError(input, "This field is required")
    } else if (input.type === "email" && input.value && !validateEmail(input.value)) {
      isValid = false
      showError(input, "Please enter a valid email address")
    } else if (input.type === "tel" && input.value && !validatePhone(input.value)) {
      isValid = false
      showError(input, "Please enter a valid phone number")
    } else {
      clearError(input)
    }
  })

  if (!isValid) {
    event.preventDefault()
  }
}

function showError(input, message) {
  const formGroup = input.closest(".form-group") || input.parentElement
  const errorElement = formGroup.querySelector(".error-message") || document.createElement("div")

  errorElement.className = "error-message"
  errorElement.textContent = message

  if (!formGroup.querySelector(".error-message")) {
    formGroup.appendChild(errorElement)
  }

  input.classList.add("error")
}

function clearError(input) {
  const formGroup = input.closest(".form-group") || input.parentElement
  const errorElement = formGroup.querySelector(".error-message")

  if (errorElement) {
    formGroup.removeChild(errorElement)
  }

  input.classList.remove("error")
}

function validateEmail(email) {
  const re =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  return re.test(String(email).toLowerCase())
}

function validatePhone(phone) {
  const re = /^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/
  return re.test(String(phone))
}

// Search functionality
function initializeSearchFunctionality() {
  const searchForms = document.querySelectorAll(".search-form, .search-container form")

  searchForms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      e.preventDefault()

      const input = this.querySelector("input")
      const searchTerm = input.value.trim()

      if (searchTerm !== "") {
        // In a real application, this would redirect to search results
        // For now, we'll just show an alert
        alert(`Searching for: ${searchTerm}`)
      }
    })
  })
}
