// Money Rates Page Interactions
document.addEventListener("DOMContentLoaded", () => {
  initializeRatesTabs()
  initializeRatesChart()
  initializeRatesTable()
  initializeCurrencyConverter()
})

// Rates Tabs
function initializeRatesTabs() {
  const tabButtons = document.querySelectorAll(".rates-tab-button")
  const tabContents = document.querySelectorAll(".rates-tab-content")

  if (tabButtons.length > 0 && tabContents.length > 0) {
    tabButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const tabId = this.getAttribute("data-tab")

        // Update active tab button
        tabButtons.forEach((btn) => btn.classList.remove("active"))
        this.classList.add("active")

        // Show active tab content
        tabContents.forEach((content) => {
          content.classList.remove("active")
          if (content.getAttribute("id") === tabId) {
            content.classList.add("active")
          }
        })
      })
    })
  }
}

// Rates Chart
function initializeRatesChart() {
  const chartContainer = document.querySelector(".rates-chart")

  if (chartContainer) {
    // Simulate chart with canvas
    const canvas = document.createElement("canvas")
    canvas.classList.add("rates-chart-canvas")
    chartContainer.appendChild(canvas)

    const ctx = canvas.getContext("2d")

    // Set canvas size
    function resizeCanvas() {
      canvas.width = chartContainer.offsetWidth
      canvas.height = 300
      drawChart()
    }

    resizeCanvas()
    window.addEventListener("resize", resizeCanvas)

    // Draw chart
    function drawChart() {
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Generate random data
      const dataPoints = 12
      const data = []

      for (let i = 0; i < dataPoints; i++) {
        data.push(Math.random() * 50 + 50)
      }

      // Draw grid
      ctx.strokeStyle = "#eee"
      ctx.lineWidth = 1

      // Horizontal grid lines
      for (let i = 0; i <= 5; i++) {
        const y = i * (canvas.height / 5)
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(canvas.width, y)
        ctx.stroke()
      }

      // Vertical grid lines
      for (let i = 0; i <= dataPoints; i++) {
        const x = i * (canvas.width / dataPoints)
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, canvas.height)
        ctx.stroke()
      }

      // Draw line
      ctx.strokeStyle = "#4a90e2"
      ctx.lineWidth = 3
      ctx.beginPath()

      for (let i = 0; i < dataPoints; i++) {
        const x = i * (canvas.width / (dataPoints - 1))
        const y = canvas.height - (data[i] / 100) * canvas.height

        if (i === 0) {
          ctx.moveTo(x, y)
        } else {
          ctx.lineTo(x, y)
        }
      }

      ctx.stroke()

      // Draw points
      ctx.fillStyle = "#4a90e2"

      for (let i = 0; i < dataPoints; i++) {
        const x = i * (canvas.width / (dataPoints - 1))
        const y = canvas.height - (data[i] / 100) * canvas.height

        ctx.beginPath()
        ctx.arc(x, y, 5, 0, Math.PI * 2)
        ctx.fill()
      }

      // Draw labels
      ctx.fillStyle = "#333"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"

      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

      for (let i = 0; i < dataPoints; i++) {
        const x = i * (canvas.width / (dataPoints - 1))
        const y = canvas.height - 10

        ctx.fillText(months[i], x, y)
      }
    }

    // Add interactivity
    canvas.addEventListener("mousemove", (e) => {
      const rect = canvas.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      // Find closest data point
      const dataPoints = 12
      const pointWidth = canvas.width / (dataPoints - 1)

      for (let i = 0; i < dataPoints; i++) {
        const pointX = i * pointWidth

        if (Math.abs(x - pointX) < 10) {
          // Clear previous tooltip
          ctx.clearRect(0, 0, canvas.width, canvas.height)
          drawChart()

          // Draw tooltip
          const tooltipWidth = 80
          const tooltipHeight = 30
          const tooltipX = pointX - tooltipWidth / 2
          const tooltipY = 20

          ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
          ctx.fillRect(tooltipX, tooltipY, tooltipWidth, tooltipHeight)

          ctx.fillStyle = "#fff"
          ctx.font = "12px Arial"
          ctx.textAlign = "center"
          ctx.fillText(`Value: ${Math.round(Math.random() * 50 + 50)}`, pointX, tooltipY + 20)

          break
        }
      }
    })
  }
}

// Rates Table
function initializeRatesTable() {
    const ratesTable = document.querySelector('.rates-table');
    
    if (ratesTable) {
        // Add sorting functionality
        const headers = ratesTable.querySelectorAll('th');
        
        headers.forEach(header => {
            if (header.getAttribute('data-sortable') === 'true') {
                header.classList.add('sortable');
                
                header.addEventListener('click', function() {
                    const column = this.getAttribute('data-column');
                    const currentDirection = this.getAttribute('data-direction') || 'asc';
                    const newDirection = currentDirection === 'asc' ? 'desc' : 'asc';
