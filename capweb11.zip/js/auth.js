// Common authentication functions

// Form validation
function validateEmail(email) {
  const re =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
  return re.test(String(email).toLowerCase())
}

function validatePassword(password) {
  return password.length >= 6
}

function validatePhone(phone) {
  return phone.length >= 10
}

function validateName(name) {
  return name.length >= 2
}

// Show error message
function showError(inputElement, errorMessage) {
  const errorElement = inputElement.nextElementSibling
  if (errorElement && errorElement.classList.contains("error-message")) {
    errorElement.textContent = errorMessage
    errorElement.style.display = "block"
    inputElement.style.borderColor = "#e53935"
  }
}

// Hide error message
function hideError(inputElement) {
  const errorElement = inputElement.nextElementSibling
  if (errorElement && errorElement.classList.contains("error-message")) {
    errorElement.style.display = "none"
    inputElement.style.borderColor = "#ddd"
  }
}

// Page transitions
function navigateTo(url) {
  document.body.classList.add("page-transition")
  setTimeout(() => {
    window.location.href = url
  }, 300)
}

// Initialize page-specific scripts
document.addEventListener("DOMContentLoaded", () => {
  document.body.classList.add("page-transition")

  // SignUpForm validation
  const signUpForm = document.getElementById("signUpForm")
  if (signUpForm) {
    const firstNameInput = document.getElementById("firstName")
    const lastNameInput = document.getElementById("lastName")
    const phoneInput = document.getElementById("phoneNumber")
    const emailInput = document.getElementById("email")
    const passwordInput = document.getElementById("password")
    const confirmPasswordInput = document.getElementById("confirmPassword")
    const termsCheckbox = document.getElementById("terms")
    const signUpButton = document.getElementById("signUpButton")

    // Add validation on input
    if (firstNameInput) {
      firstNameInput.addEventListener("input", function () {
        if (!validateName(this.value)) {
          showError(this, "First name must be at least 2 characters")
        } else {
          hideError(this)
        }
        updateSignUpButtonState()
      })
    }

    if (lastNameInput) {
      lastNameInput.addEventListener("input", function () {
        if (!validateName(this.value)) {
          showError(this, "Last name must be at least 2 characters")
        } else {
          hideError(this)
        }
        updateSignUpButtonState()
      })
    }

    if (phoneInput) {
      phoneInput.addEventListener("input", function () {
        if (!validatePhone(this.value)) {
          showError(this, "Please enter a valid phone number")
        } else {
          hideError(this)
        }
        updateSignUpButtonState()
      })
    }

    if (emailInput) {
      emailInput.addEventListener("input", function () {
        if (!validateEmail(this.value)) {
          showError(this, "Please enter a valid email address")
        } else {
          hideError(this)
        }
        updateSignUpButtonState()
      })
    }

    if (passwordInput) {
      passwordInput.addEventListener("input", function () {
        if (!validatePassword(this.value)) {
          showError(this, "Password must be at least 6 characters")
        } else {
          hideError(this)
        }

        // Check password match if confirm password has value
        if (confirmPasswordInput && confirmPasswordInput.value) {
          if (this.value !== confirmPasswordInput.value) {
            document.getElementById("passwordMatchError").style.display = "block"
          } else {
            document.getElementById("passwordMatchError").style.display = "none"
          }
        }

        updateSignUpButtonState()
      })
    }

    if (confirmPasswordInput) {
      confirmPasswordInput.addEventListener("input", function () {
        if (passwordInput && this.value !== passwordInput.value) {
          document.getElementById("passwordMatchError").style.display = "block"
        } else {
          document.getElementById("passwordMatchError").style.display = "none"
        }
        updateSignUpButtonState()
      })
    }

    if (termsCheckbox) {
      termsCheckbox.addEventListener("change", updateSignUpButtonState)
    }

    // Form submission
    signUpForm.addEventListener("submit", (e) => {
      e.preventDefault()

      if (isSignUpFormValid()) {
        // Simulate form submission
        signUpButton.disabled = true
        signUpButton.textContent = "Signing up..."

        setTimeout(() => {
          navigateTo("LoginPage.html")
        }, 1500)
      }
    })

    function updateSignUpButtonState() {
      if (signUpButton) {
        signUpButton.disabled = !isSignUpFormValid()
      }
    }

    function isSignUpFormValid() {
      let isValid = true

      if (firstNameInput && !validateName(firstNameInput.value)) isValid = false
      if (lastNameInput && !validateName(lastNameInput.value)) isValid = false
      if (phoneInput && !validatePhone(phoneInput.value)) isValid = false
      if (emailInput && !validateEmail(emailInput.value)) isValid = false
      if (passwordInput && !validatePassword(passwordInput.value)) isValid = false
      if (confirmPasswordInput && passwordInput && confirmPasswordInput.value !== passwordInput.value) isValid = false
      if (termsCheckbox && !termsCheckbox.checked) isValid = false

      return isValid
    }

    // Initialize button state
    updateSignUpButtonState()
  }

  // Login form validation
  const loginForm = document.getElementById("loginForm")
  if (loginForm) {
    const emailInput = document.getElementById("email")
    const passwordInput = document.getElementById("password")
    const loginButton = document.getElementById("loginButton")

    if (emailInput) {
      emailInput.addEventListener("input", function () {
        if (!validateEmail(this.value)) {
          showError(this, "Please enter a valid email address")
        } else {
          hideError(this)
        }
        updateLoginButtonState()
      })
    }

    if (passwordInput) {
      passwordInput.addEventListener("input", function () {
        if (!validatePassword(this.value)) {
          showError(this, "Password must be at least 6 characters")
        } else {
          hideError(this)
        }
        updateLoginButtonState()
      })
    }

    loginForm.addEventListener("submit", (e) => {
      e.preventDefault()

      if (isLoginFormValid()) {
        // Simulate form submission
        loginButton.disabled = true
        loginButton.textContent = "Logging in..."

        setTimeout(() => {
          navigateTo("index.html")
        }, 1500)
      }
    })

    function updateLoginButtonState() {
      if (loginButton) {
        loginButton.disabled = !isLoginFormValid()
      }
    }

    function isLoginFormValid() {
      let isValid = true

      if (emailInput && !validateEmail(emailInput.value)) isValid = false
      if (passwordInput && !validatePassword(passwordInput.value)) isValid = false

      return isValid
    }

    // Initialize button state
    updateLoginButtonState()
  }

  // Forgot password form
  const forgotPasswordForm = document.getElementById("forgotPasswordForm")
  if (forgotPasswordForm) {
    const emailInput = document.getElementById("email")
    const confirmButton = document.getElementById("confirmEmailButton")

    if (emailInput) {
      emailInput.addEventListener("input", function () {
        if (!validateEmail(this.value)) {
          showError(this, "Please enter a valid email address")
          confirmButton.disabled = true
        } else {
          hideError(this)
          confirmButton.disabled = false
        }
      })
    }

    forgotPasswordForm.addEventListener("submit", (e) => {
      e.preventDefault()

      if (emailInput && validateEmail(emailInput.value)) {
        // Simulate form submission
        confirmButton.disabled = true
        confirmButton.textContent = "Sending code..."

        setTimeout(() => {
          navigateTo("CodeEntering.html")
        }, 1500)
      }
    })
  }

  // Code entering page
  const codeInputs = document.querySelectorAll(".code-input")
  if (codeInputs.length > 0) {
    const verifyButton = document.getElementById("verifyCodeButton")

    codeInputs.forEach((input, index) => {
      // Focus next input when a digit is entered
      input.addEventListener("input", function () {
        if (this.value.length === 1) {
          if (index < codeInputs.length - 1) {
            codeInputs[index + 1].focus()
          } else {
            // All inputs filled
            verifyButton.disabled = false
          }
        } else {
          verifyButton.disabled = true
        }
      })

      // Handle backspace to go to previous input
      input.addEventListener("keydown", function (e) {
        if (e.key === "Backspace" && !this.value && index > 0) {
          codeInputs[index - 1].focus()
        }
      })
    })

    // Verify code button
    if (verifyButton) {
      verifyButton.addEventListener("click", () => {
        let allFilled = true
        codeInputs.forEach((input) => {
          if (!input.value) {
            allFilled = false
          }
        })

        if (allFilled) {
          verifyButton.disabled = true
          verifyButton.textContent = "Verifying..."

          setTimeout(() => {
            navigateTo("PasswordReset.html")
          }, 1500)
        }
      })
    }
  }

  // Password reset page
  const resetPasswordForm = document.getElementById("resetPasswordForm")
  if (resetPasswordForm) {
    const passwordInput = document.getElementById("password")
    const confirmPasswordInput = document.getElementById("confirm-password")
    const resetButton = document.getElementById("resetPasswordButton")

    if (passwordInput) {
      passwordInput.addEventListener("input", function () {
        if (!validatePassword(this.value)) {
          showError(this, "Password must be at least 6 characters")
        } else {
          hideError(this)
        }

        // Check password match if confirm password has value
        if (confirmPasswordInput && confirmPasswordInput.value) {
          if (this.value !== confirmPasswordInput.value) {
            document.getElementById("passwordMatchError").style.display = "block"
          } else {
            document.getElementById("passwordMatchError").style.display = "none"
          }
        }

        updateResetButtonState()
      })
    }

    if (confirmPasswordInput) {
      confirmPasswordInput.addEventListener("input", function () {
        if (passwordInput && this.value !== passwordInput.value) {
          document.getElementById("passwordMatchError").style.display = "block"
        } else {
          document.getElementById("passwordMatchError").style.display = "none"
        }
        updateResetButtonState()
      })
    }

    resetPasswordForm.addEventListener("submit", (e) => {
      e.preventDefault()

      if (isResetFormValid()) {
        // Simulate form submission
        resetButton.disabled = true
        resetButton.textContent = "Resetting password..."

        setTimeout(() => {
          navigateTo("LoginPage.html")
        }, 1500)
      }
    })

    function updateResetButtonState() {
      if (resetButton) {
        resetButton.disabled = !isResetFormValid()
      }
    }

    function isResetFormValid() {
      let isValid = true

      if (passwordInput && !validatePassword(passwordInput.value)) isValid = false
      if (confirmPasswordInput && passwordInput && confirmPasswordInput.value !== passwordInput.value) isValid = false

      return isValid
    }

    // Initialize button state
    updateResetButtonState()
  }
})
