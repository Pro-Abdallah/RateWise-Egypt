document.addEventListener("DOMContentLoaded", () => {
  // Load navbar
  const navbarContainer = document.getElementById("navbar-container")
  if (navbarContainer) {
    fetch("components/navbar.html")
      .then((response) => response.text())
      .then((data) => {
        navbarContainer.innerHTML = data

        // Highlight current page in navbar
        const currentPage = window.location.pathname.split("/").pop() || "index.html"
        const navLinks = navbarContainer.querySelectorAll(".nav-link")

        navLinks.forEach((link) => {
          const linkHref = link.getAttribute("href")
          if (
            linkHref === currentPage ||
            (currentPage === "" && linkHref === "index.html") ||
            (currentPage === "index.html" && linkHref === "index.html")
          ) {
            link.classList.add("active")
          }

          // Add hover effect
          link.addEventListener("mouseenter", function () {
            if (!this.classList.contains("active")) {
              this.style.color = "#0d8bf2"
            }
          })

          link.addEventListener("mouseleave", function () {
            if (!this.classList.contains("active")) {
              this.style.color = ""
            }
          })
        })

        // Add navigation function to register button
        const registerBtn = navbarContainer.querySelector(".register-btn")
        if (registerBtn) {
          registerBtn.addEventListener("click", () => {
            navigateTo("SignUpOptions.html")
          })

          // Add hover effect
          registerBtn.addEventListener("mouseenter", function () {
            this.style.backgroundColor = "#0a6fc0"
          })

          registerBtn.addEventListener("mouseleave", function () {
            this.style.backgroundColor = ""
          })
        }
      })
      .catch((error) => console.error("Error loading navbar:", error))
  }

  // Load footer
  const footerContainer = document.getElementById("footer-container")
  if (footerContainer) {
    fetch("components/footer.html")
      .then((response) => response.text())
      .then((data) => {
        footerContainer.innerHTML = data
      })
      .catch((error) => console.error("Error loading footer:", error))
  }
})

// Page transition function
function navigateTo(url) {
  document.body.classList.add("page-transition")
  setTimeout(() => {
    window.location.href = url
  }, 300)
}

// Make navigateTo function globally available
window.navigateTo = navigateTo
