// Product Details Page Interactions
document.addEventListener("DOMContentLoaded", () => {
  initializeProductGallery()
  initializeColorSelector()
  initializeQuantitySelector()
  initializeProductTabs()
  initializeAddToCart()
  initializeRelatedProducts()
})

// Product Gallery
function initializeProductGallery() {
  const mainImage = document.querySelector(".product-main-image img")
  const thumbnails = document.querySelectorAll(".product-thumbnail")

  if (mainImage && thumbnails.length > 0) {
    thumbnails.forEach((thumbnail) => {
      thumbnail.addEventListener("click", function () {
        // Update active thumbnail
        thumbnails.forEach((t) => t.classList.remove("active"))
        this.classList.add("active")

        // Update main image
        const imgSrc = this.querySelector("img").getAttribute("src")
        mainImage.setAttribute("src", imgSrc)

        // Add zoom effect
        mainImage.classList.add("zoom")
        setTimeout(() => {
          mainImage.classList.remove("zoom")
        }, 300)
      })
    })

    // Image zoom on hover
    const imageContainer = document.querySelector(".product-main-image")

    if (imageContainer) {
      imageContainer.addEventListener("mousemove", function (e) {
        const { left, top, width, height } = this.getBoundingClientRect()
        const x = ((e.clientX - left) / width) * 100
        const y = ((e.clientY - top) / height) * 100

        mainImage.style.transformOrigin = `${x}% ${y}%`
      })

      imageContainer.addEventListener("mouseenter", () => {
        mainImage.style.transform = "scale(1.5)"
      })

      imageContainer.addEventListener("mouseleave", () => {
        mainImage.style.transform = "scale(1)"
        mainImage.style.transformOrigin = "center center"
      })
    }
  }
}

// Color Selector
function initializeColorSelector() {
  const colorOptions = document.querySelectorAll(".color-option")

  if (colorOptions.length > 0) {
    colorOptions.forEach((option) => {
      option.addEventListener("click", function () {
        // Update active color
        colorOptions.forEach((o) => o.classList.remove("active"))
        this.classList.add("active")

        // Update selected color text if exists
        const selectedColorText = document.querySelector(".selected-color-text")
        if (selectedColorText) {
          selectedColorText.textContent = this.getAttribute("data-color-name")
        }
      })
    })
  }
}

// Quantity Selector
function initializeQuantitySelector() {
  const quantityInput = document.querySelector(".quantity-input")
  const decreaseBtn = document.querySelector(".quantity-decrease")
  const increaseBtn = document.querySelector(".quantity-increase")

  if (quantityInput && decreaseBtn && increaseBtn) {
    decreaseBtn.addEventListener("click", () => {
      let value = Number.parseInt(quantityInput.value)
      if (value > 1) {
        value--
        quantityInput.value = value

        // Trigger change event
        const event = new Event("change")
        quantityInput.dispatchEvent(event)
      }
    })

    increaseBtn.addEventListener("click", () => {
      let value = Number.parseInt(quantityInput.value)
      value++
      quantityInput.value = value

      // Trigger change event
      const event = new Event("change")
      quantityInput.dispatchEvent(event)
    })

    // Validate input
    quantityInput.addEventListener("change", function () {
      const value = Number.parseInt(this.value)
      if (isNaN(value) || value < 1) {
        this.value = 1
      }
    })
  }
}

// Product Tabs
function initializeProductTabs() {
  const tabButtons = document.querySelectorAll(".product-tab-button")
  const tabContents = document.querySelectorAll(".product-tab-content")

  if (tabButtons.length > 0 && tabContents.length > 0) {
    tabButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const tabId = this.getAttribute("data-tab")

        // Update active tab button
        tabButtons.forEach((btn) => btn.classList.remove("active"))
        this.classList.add("active")

        // Show active tab content
        tabContents.forEach((content) => {
          content.classList.remove("active")
          if (content.getAttribute("id") === tabId) {
            content.classList.add("active")
          }
        })
      })
    })
  }
}

// Add to Cart Animation
function initializeAddToCart() {
  const addToCartBtn = document.querySelector(".add-to-cart-btn")
  const cartIcon = document.querySelector(".cart-icon")

  if (addToCartBtn && cartIcon) {
    addToCartBtn.addEventListener("click", (e) => {
      e.preventDefault()

      // Create flying element
      const productImage = document.querySelector(".product-main-image img")
      const flyingImage = document.createElement("img")

      flyingImage.setAttribute("src", productImage.getAttribute("src"))
      flyingImage.classList.add("flying-image")

      document.body.appendChild(flyingImage)

      // Get positions
      const buttonRect = addToCartBtn.getBoundingClientRect()
      const cartRect = cartIcon.getBoundingClientRect()

      // Set initial position
      flyingImage.style.top = buttonRect.top + "px"
      flyingImage.style.left = buttonRect.left + "px"
      flyingImage.style.width = "50px"
      flyingImage.style.height = "50px"

      // Animate to cart
      setTimeout(() => {
        flyingImage.style.top = cartRect.top + "px"
        flyingImage.style.left = cartRect.left + "px"
        flyingImage.style.width = "20px"
        flyingImage.style.height = "20px"
        flyingImage.style.opacity = "0"
      }, 10)

      // Remove flying image and update cart
      setTimeout(() => {
        flyingImage.remove()

        // Update cart count
        const cartCount = document.querySelector(".cart-count")
        if (cartCount) {
          let count = Number.parseInt(cartCount.textContent)
          count += Number.parseInt(document.querySelector(".quantity-input").value)
          cartCount.textContent = count

          // Animate cart count
          cartCount.classList.add("pulse")
          setTimeout(() => {
            cartCount.classList.remove("pulse")
          }, 300)
        }

        // Show success message
        const successMessage = document.createElement("div")
        successMessage.classList.add("add-to-cart-success")
        successMessage.textContent = "Product added to cart!"

        document.body.appendChild(successMessage)

        setTimeout(() => {
          successMessage.classList.add("show")
        }, 10)

        setTimeout(() => {
          successMessage.classList.remove("show")
          setTimeout(() => {
            successMessage.remove()
          }, 300)
        }, 2000)
      }, 1000)
    })
  }
}

// Related Products Slider
function initializeRelatedProducts() {
  const relatedProductsContainer = document.querySelector(".related-products")
  const productCards = document.querySelectorAll(".related-products .product-card")

  if (relatedProductsContainer && productCards.length > 0) {
    // Add navigation buttons if not already present
    if (!document.querySelector(".related-products-nav")) {
      const navContainer = document.createElement("div")
      navContainer.classList.add("related-products-nav")

      const prevBtn = document.createElement("button")
      prevBtn.classList.add("related-prev-btn")
      prevBtn.innerHTML = "&larr;"

      const nextBtn = document.createElement("button")
      nextBtn.classList.add("related-next-btn")
      nextBtn.innerHTML = "&rarr;"

      navContainer.appendChild(prevBtn)
      navContainer.appendChild(nextBtn)

      relatedProductsContainer.appendChild(navContainer)

      // Add event listeners
      let currentPosition = 0
      const cardWidth = productCards[0].offsetWidth + 20 // Width + margin
      const visibleCards = Math.floor(relatedProductsContainer.offsetWidth / cardWidth)
      const maxPosition = productCards.length - visibleCards

      prevBtn.addEventListener("click", () => {
        if (currentPosition > 0) {
          currentPosition--
          updatePosition()
        }
      })

      nextBtn.addEventListener("click", () => {
        if (currentPosition < maxPosition) {
          currentPosition++
          updatePosition()
        }
      })

      function updatePosition() {
        const translateX = -currentPosition * cardWidth
        document.querySelector(".related-products-grid").style.transform = `translateX(${translateX}px)`
      }
    }
  }
}
// Wishlist button functionality
function initializeWishlistButton() {
  const wishlistBtn = document.getElementById("wishlistBtn")
  const actionIcons = document.querySelectorAll(".action-icon i.fa-heart")

  if (wishlistBtn) {
    wishlistBtn.addEventListener("click", function () {
      const heartIcon = this.querySelector("i")

      if (heartIcon.classList.contains("far")) {
        heartIcon.classList.remove("far")
        heartIcon.classList.add("fas")
        heartIcon.classList.add("heart-active")

        // Show a notification
        showNotification("Product added to wishlist!")
      } else {
        heartIcon.classList.remove("fas")
        heartIcon.classList.remove("heart-active")
        heartIcon.classList.add("far")

        // Show a notification
        showNotification("Product removed from wishlist!")
      }
    })
  }

  actionIcons.forEach((icon) => {
    icon.parentElement.addEventListener("click", function () {
      const heartIcon = this.querySelector("i")

      if (heartIcon.classList.contains("far")) {
        heartIcon.classList.remove("far")
        heartIcon.classList.add("fas")
        heartIcon.classList.add("heart-active")

        // Show a notification
        showNotification("Product added to wishlist!")
      } else {
        heartIcon.classList.remove("fas")
        heartIcon.classList.remove("heart-active")
        heartIcon.classList.add("far")

        // Show a notification
        showNotification("Product removed from wishlist!")
      }
    })
  })
}

// Share button functionality
function initializeShareButton() {
  const shareBtn = document.querySelector(".share-btn")

  if (shareBtn) {
    shareBtn.addEventListener("click", () => {
      // In a real application, this would open a share dialog
      // For now, we'll just show a notification
      showNotification("Sharing options would appear here!")
    })
  }
}

// Related products slider functionality
function initializeRelatedProductsSlider() {
  const productCards = document.querySelectorAll(".products-grid .product-card")

  productCards.forEach((card) => {
    card.addEventListener("click", () => {
      // In a real application, this would navigate to the product page
      // For now, we'll just show a notification
      showNotification("Navigating to product details...")
    })

    // Add hover effect for "Have A Look!" overlay
    const overlay = card.querySelector(".look-btn-overlay")

    if (overlay) {
      card.addEventListener("mouseenter", () => {
        overlay.style.bottom = "0"
      })

      card.addEventListener("mouseleave", () => {
        overlay.style.bottom = "-40px"
      })
    }
  })
}

// Product zoom functionality
function initializeProductZoom() {
  const mainImage = document.querySelector(".main-image")
  const zoomOverlay = document.querySelector(".image-zoom-overlay")

  if (mainImage && zoomOverlay) {
    zoomOverlay.addEventListener("click", () => {
      // In a real application, this would open a lightbox
      // For now, we'll just show a notification
      showNotification("Image zoom would open here!")
    })
  }
}

// Notification functionality
function showNotification(message) {
  // Create notification element if it doesn't exist
  let notification = document.querySelector(".notification")

  if (!notification) {
    notification = document.createElement("div")
    notification.className = "notification"
    document.body.appendChild(notification)
  }

  // Set message and show notification
  notification.textContent = message
  notification.classList.add("show")

  // Hide notification after 3 seconds
  setTimeout(() => {
    notification.classList.remove("show")
  }, 3000)
}

// Add notification styles
const style = document.createElement("style")
style.textContent = `
  .notification {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #333;
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    transform: translateY(100px);
    opacity: 0;
    transition: transform 0.3s ease, opacity 0.3s ease;
  }
  
  .notification.show {
    transform: translateY(0);
    opacity: 1;
  }
`
document.head.appendChild(style)
